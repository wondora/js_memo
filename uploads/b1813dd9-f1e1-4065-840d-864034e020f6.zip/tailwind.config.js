/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './templates/**/*.html',
    './**/templates/**/*.html',
    // Django 앱 내의 템플릿 파일도 포함
    './board/templates/**/*.html',
    './theme/templates/**/*.html',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}